"""AI Chessathon submission: lightweight agentic alpha-beta chess player.

No third-party chess engine, network calls, subprocesses, or external model are used.
The "agentic" layer is a small controller that classifies the position and adapts
search budget, tactical emphasis, and evaluation weights before iterative deepening.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Optional

import chess

# ---------------------------------------------------------------------------
# Constants / evaluation tables
# ---------------------------------------------------------------------------
INF = 10_000_000
MATE = 1_000_000
MAX_TT = 180_000

VALUES = {
    chess.PAWN: 100,
    chess.KNIGHT: 320,
    chess.BISHOP: 330,
    chess.ROOK: 500,
    chess.QUEEN: 900,
    chess.KING: 20_000,
}

# Tables are from White's point of view; black squares are mirrored.
PST = {
    chess.PAWN: [
          0,  0,  0,  0,  0,  0,  0,  0,
         50, 50, 50, 50, 50, 50, 50, 50,
         10, 10, 20, 30, 30, 20, 10, 10,
          5,  5, 10, 25, 25, 10,  5,  5,
          0,  0,  0, 20, 20,  0,  0,  0,
          5, -5,-10,  0,  0,-10, -5,  5,
          5, 10, 10,-20,-20, 10, 10,  5,
          0,  0,  0,  0,  0,  0,  0,  0,
    ],
    chess.KNIGHT: [
        -50,-40,-30,-30,-30,-30,-40,-50,
        -40,-20,  0,  0,  0,  0,-20,-40,
        -30,  0, 10, 15, 15, 10,  0,-30,
        -30,  5, 15, 20, 20, 15,  5,-30,
        -30,  0, 15, 20, 20, 15,  0,-30,
        -30,  5, 10, 15, 15, 10,  5,-30,
        -40,-20,  0,  5,  5,  0,-20,-40,
        -50,-40,-30,-30,-30,-30,-40,-50,
    ],
    chess.BISHOP: [
        -20,-10,-10,-10,-10,-10,-10,-20,
        -10,  0,  0,  0,  0,  0,  0,-10,
        -10,  0,  5, 10, 10,  5,  0,-10,
        -10,  5,  5, 10, 10,  5,  5,-10,
        -10,  0, 10, 10, 10, 10,  0,-10,
        -10, 10, 10, 10, 10, 10, 10,-10,
        -10,  5,  0,  0,  0,  0,  5,-10,
        -20,-10,-10,-10,-10,-10,-10,-20,
    ],
    chess.ROOK: [
          0,  0,  0,  5,  5,  0,  0,  0,
         -5,  0,  0,  0,  0,  0,  0, -5,
         -5,  0,  0,  0,  0,  0,  0, -5,
         -5,  0,  0,  0,  0,  0,  0, -5,
         -5,  0,  0,  0,  0,  0,  0, -5,
         -5,  0,  0,  0,  0,  0,  0, -5,
          5, 10, 10, 10, 10, 10, 10,  5,
          0,  0,  0,  0,  0,  0,  0,  0,
    ],
    chess.QUEEN: [
        -20,-10,-10, -5, -5,-10,-10,-20,
        -10,  0,  0,  0,  0,  0,  0,-10,
        -10,  0,  5,  5,  5,  5,  0,-10,
         -5,  0,  5,  5,  5,  5,  0, -5,
          0,  0,  5,  5,  5,  5,  0, -5,
        -10,  5,  5,  5,  5,  5,  0,-10,
        -10,  0,  5,  0,  0,  0,  0,-10,
        -20,-10,-10, -5, -5,-10,-10,-20,
    ],
    chess.KING: [
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -20,-30,-30,-40,-40,-30,-30,-20,
        -10,-20,-20,-20,-20,-20,-20,-10,
         20, 20,  0,  0,  0,  0, 20, 20,
         20, 30, 10,  0,  0, 10, 30, 20,
    ],
}

# Endgame king table: active king is much more valuable than a tucked king.
KING_END = [
    -50,-30,-30,-30,-30,-30,-30,-50,
    -30,-10,  0,  0,  0,  0,-10,-30,
    -30,  0, 20, 30, 30, 20,  0,-30,
    -30,  0, 30, 40, 40, 30,  0,-30,
    -30,  0, 30, 40, 40, 30,  0,-30,
    -30,  0, 20, 30, 30, 20,  0,-30,
    -30,-10,  0,  0,  0,  0,-10,-30,
    -50,-30,-30,-30,-30,-30,-30,-50,
]

@dataclass(slots=True)
class TTEntry:
    depth: int
    score: int
    flag: int  # 0 exact, -1 upper, 1 lower
    move: Optional[chess.Move]

TT: dict[object, TTEntry] = {}
HISTORY = [[0] * 64 for _ in range(2)]
KILLERS: list[list[Optional[chess.Move]]] = [[None, None] for _ in range(64)]
NODE_LIMIT = INF
DEADLINE = 0.0
NODES = 0


def _mirror(square: int) -> int:
    return chess.square_mirror(square)


def _pst(piece_type: int, square: int, color: bool, endgame: bool) -> int:
    sq = square if color == chess.WHITE else _mirror(square)
    if piece_type == chess.KING and endgame:
        return KING_END[sq]
    return PST[piece_type][sq]


def _phase(board: chess.Board) -> int:
    # 0..24, where 24 is full middlegame material.
    weights = {chess.KNIGHT: 1, chess.BISHOP: 1, chess.ROOK: 2, chess.QUEEN: 4}
    phase = 0
    for p, w in weights.items():
        phase += w * (len(board.pieces(p, chess.WHITE)) + len(board.pieces(p, chess.BLACK)))
    return min(24, phase)


def _is_endgame(board: chess.Board, phase: int) -> bool:
    return phase <= 8 or (len(board.piece_map()) <= 10)


def evaluate(board: chess.Board, controller_bonus: int = 0) -> int:
    """Static score from side-to-move perspective."""
    phase = _phase(board)
    endgame = _is_endgame(board, phase)
    score = 0
    bishops = [0, 0]
    pawns = [0, 0]
    for sq, piece in board.piece_map().items():
        sign = 1 if piece.color == board.turn else -1
        v = VALUES[piece.piece_type]
        score += sign * (v + _pst(piece.piece_type, sq, piece.color, endgame))
        if piece.piece_type == chess.BISHOP:
            bishops[0 if piece.color == board.turn else 1] += 1
        elif piece.piece_type == chess.PAWN:
            pawns[0 if piece.color == board.turn else 1] += 1

    # Bishop pair.
    if bishops[0] >= 2:
        score += 28
    if bishops[1] >= 2:
        score -= 28

    # Mobility is expensive but highly useful; scale it modestly.
    own_mob = board.legal_moves.count()
    # Avoid a second full legal move generation by counting opponent mobility only
    # in the upper search layers (controller_bonus carries extra tactical emphasis).
    score += 4 * own_mob + controller_bonus

    # Pawn structure: doubled/isolated pawns are weak; passed pawns get a bonus.
    for color_idx, color in enumerate((board.turn, not board.turn)):
        files = [len(board.pieces(chess.PAWN, color) & chess.BB_FILES[f]) for f in range(8)]
        doubled = sum(max(0, n - 1) for n in files)
        isolated = 0
        for f, n in enumerate(files):
            if n and (f == 0 or files[f - 1] == 0) and (f == 7 or files[f + 1] == 0):
                isolated += n
        pawn_term = -(12 * doubled + 8 * isolated)
        sign = 1 if color == board.turn else -1
        score += sign * pawn_term

    # Rooks on open/semi-open files.
    for color in (board.turn, not board.turn):
        sign = 1 if color == board.turn else -1
        for sq in board.pieces(chess.ROOK, color):
            f = chess.square_file(sq)
            own_pawn = any(chess.square_file(p) == f for p in board.pieces(chess.PAWN, color))
            opp_pawn = any(chess.square_file(p) == f for p in board.pieces(chess.PAWN, not color))
            if not own_pawn:
                score += sign * (14 if opp_pawn else 24)

    # King safety in the middlegame: castled king is preferable, exposed king gets penalized.
    if not endgame:
        for color in (board.turn, not board.turn):
            sign = 1 if color == board.turn else -1
            k = board.king(color)
            if k is not None:
                file_ = chess.square_file(k)
                rank = chess.square_rank(k)
                if (color == chess.WHITE and rank == 0 and file_ in (1, 2, 6)) or (
                    color == chess.BLACK and rank == 7 and file_ in (1, 2, 6)
                ):
                    score += sign * 18

    return score


def _time_check() -> bool:
    return time.perf_counter() >= DEADLINE


def _capture_score(board: chess.Board, move: chess.Move) -> int:
    attacker = board.piece_at(move.from_square)
    victim = board.piece_at(move.to_square)
    if victim is None and board.is_en_passant(move):
        victim_value = VALUES[chess.PAWN]
    else:
        victim_value = VALUES[victim.piece_type] if victim else 0
    attacker_value = VALUES[attacker.piece_type] if attacker else 0
    promotion = VALUES.get(move.promotion, 0)
    return 10 * victim_value - attacker_value + promotion + 10_000


def _move_order(board: chess.Board, moves, tt_move: Optional[chess.Move], ply: int):
    side = 0 if board.turn == chess.WHITE else 1
    killer1, killer2 = KILLERS[min(ply, 63)]
    scored = []
    for m in moves:
        s = 0
        if tt_move is not None and m == tt_move:
            s += 2_000_000
        if board.is_capture(m):
            s += _capture_score(board, m)
        elif m.promotion:
            s += 9_000 + VALUES.get(m.promotion, 0)
        else:
            if m == killer1:
                s += 80_000
            elif m == killer2:
                s += 70_000
            s += HISTORY[side][m.to_square]
        # Checks deserve early attention without generating another board.
        if board.gives_check(m):
            s += 60_000
        scored.append((s, m))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [m for _, m in scored]


def quiescence(board: chess.Board, alpha: int, beta: int, ply: int = 0) -> int:
    global NODES
    NODES += 1
    if (NODES & 1023) == 0 and _time_check():
        raise TimeoutError

    if board.is_check():
        moves = list(board.legal_moves)
        if not moves:
            return -MATE + ply
        best = -INF
        for m in _move_order(board, moves, None, ply):
            board.push(m)
            score = -quiescence(board, -beta, -alpha, ply + 1)
            board.pop()
            if score >= beta:
                return score
            if score > best:
                best = score
            if score > alpha:
                alpha = score
        return best

    stand = evaluate(board)
    if stand >= beta:
        return stand
    if stand > alpha:
        alpha = stand

    captures = [m for m in board.legal_moves if board.is_capture(m) or m.promotion]
    for m in _move_order(board, captures, None, ply):
        # Delta pruning: don't spend time on captures that cannot catch up.
        victim = board.piece_at(m.to_square)
        gain = VALUES.get(victim.piece_type, 100) if victim else 100
        if stand + gain + 120 < alpha and not m.promotion:
            continue
        board.push(m)
        score = -quiescence(board, -beta, -alpha, ply + 1)
        board.pop()
        if score >= beta:
            return score
        if score > alpha:
            alpha = score
    return alpha


def negamax(board: chess.Board, depth: int, alpha: int, beta: int, ply: int = 0) -> int:
    global NODES
    NODES += 1
    if (NODES & 1023) == 0 and _time_check():
        raise TimeoutError

    if board.is_checkmate():
        return -MATE + ply
    if board.is_stalemate() or board.is_insufficient_material():
        return 0
    if board.halfmove_clock >= 100:
        return 0
    if depth <= 0:
        return quiescence(board, alpha, beta, ply)

    key = board._transposition_key()
    entry = TT.get(key)
    tt_move = entry.move if entry else None
    if entry and entry.depth >= depth:
        if entry.flag == 0:
            return entry.score
        if entry.flag > 0:
            alpha = max(alpha, entry.score)
        else:
            beta = min(beta, entry.score)
        if alpha >= beta:
            return entry.score

    moves = list(board.legal_moves)
    if not moves:
        return -MATE + ply if board.is_check() else 0

    orig_alpha = alpha
    best = -INF
    best_move = moves[0]
    ordered = _move_order(board, moves, tt_move, ply)

    for idx, move in enumerate(ordered):
        board.push(move)
        # Late-move reduction for quiet moves at depth >= 3. Re-search if promising.
        reduction = 1 if depth >= 3 and idx >= 6 and not board.is_check() and not move.promotion and not board.is_capture(move) else 0
        score = -negamax(board, depth - 1 - reduction, -beta, -alpha, ply + 1)
        if reduction and score > alpha:
            score = -negamax(board, depth - 1, -beta, -alpha, ply + 1)
        board.pop()

        if score > best:
            best = score
            best_move = move
        if score > alpha:
            alpha = score
        if alpha >= beta:
            if not board.is_capture(move):
                k = KILLERS[min(ply, 63)]
                if k[0] != move:
                    k[1] = k[0]
                    k[0] = move
                side = 0 if board.turn == chess.WHITE else 1
                HISTORY[side][move.to_square] = min(20_000, HISTORY[side][move.to_square] + depth * depth)
            break

    flag = 0
    if best <= orig_alpha:
        flag = -1
    elif best >= beta:
        flag = 1
    TT[key] = TTEntry(depth, best, flag, best_move)
    if len(TT) > MAX_TT:
        # Keep memory bounded; Python dict deletion is cheap compared with search.
        for _ in range(MAX_TT // 10):
            try:
                TT.pop(next(iter(TT)))
            except StopIteration:
                break
    return best


def _position_profile(board: chess.Board) -> tuple[int, int]:
    """Agentic controller: classify tactical/quiet/endgame character.

    Returns (tacticality, suggested depth). It does not use an external model or
    engine; it simply changes how the same search spends its CPU budget.
    """
    phase = _phase(board)
    tactical = 0
    if board.is_check():
        tactical += 6
    legal = list(board.legal_moves)
    captures = sum(board.is_capture(m) for m in legal)
    checks = sum(board.gives_check(m) for m in legal)
    tactical += min(5, captures)
    tactical += min(4, checks * 2)
    if len(legal) <= 8:
        tactical += 2
    if phase <= 8:
        suggested = 5
    elif tactical >= 8:
        suggested = 5
    elif tactical >= 5:
        suggested = 4
    else:
        suggested = 4
    return tactical, suggested


def _time_budget(time_left_ms: int, tactical: int) -> float:
    # Conservative: preserve enough reserve to survive the whole game.
    # The +500ms increment is not spent aggressively because it arrives only after the move.
    if time_left_ms <= 250:
        return max(0.015, time_left_ms / 1000.0 * 0.35)
    if time_left_ms <= 2_000:
        return max(0.04, time_left_ms / 1000.0 * 0.55)
    # About 3% of remaining clock + a small fixed amount; tactical positions get more.
    frac = 0.030 + min(0.012, tactical * 0.0015)
    return min(6.0, max(0.12, time_left_ms / 1000.0 * frac + 0.18))


def get_move(fen: str, time_left_ms: int) -> str:
    global DEADLINE, NODES
    board = chess.Board(fen)
    legal = list(board.legal_moves)
    if not legal:
        # Runner should never ask this, but avoid a crash on malformed edge cases.
        return "0000"
    if len(legal) == 1:
        return legal[0].uci()

    # Immediate tablebase-like handling for trivial mates/checks without shipping data.
    for m in legal:
        if board.gives_check(m):
            board.push(m)
            if board.is_checkmate():
                board.pop()
                return m.uci()
            board.pop()

    tactical, target_depth = _position_profile(board)
    budget = _time_budget(max(0, int(time_left_ms)), tactical)
    DEADLINE = time.perf_counter() + budget
    NODES = 0

    # Root ordering uses previous TT result if available.
    root_entry = TT.get(board._transposition_key())
    ordered = _move_order(board, legal, root_entry.move if root_entry else None, 0)
    best_move = ordered[0]
    best_score = -INF

    # Iterative deepening. Every completed pass is safe to return if the clock expires.
    for depth in range(1, target_depth + 4):
        if _time_check():
            break
        alpha = -INF
        beta = INF
        current_best = None
        current_score = -INF
        try:
            for move in ordered:
                if _time_check():
                    raise TimeoutError
                board.push(move)
                score = -negamax(board, depth - 1, -beta, -alpha, 1)
                board.pop()
                if score > current_score:
                    current_score = score
                    current_best = move
                if score > alpha:
                    alpha = score
            if current_best is not None:
                best_move = current_best
                best_score = current_score
                # Principal variation becomes first next iteration.
                ordered.remove(best_move)
                ordered.insert(0, best_move)
            if depth >= 2 and abs(best_score) >= MATE - 100:
                break
        except TimeoutError:
            break

    return best_move.uci()
